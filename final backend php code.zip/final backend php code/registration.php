<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
// Escape user inputs for security
$name =  $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$comp = $_POST['comp'];
$cname = $_POST['cname'];
$pno = $_POST['pno'];
$loc = $_POST['loc'];
$fund = $_POST['fund'];
$budget = $_POST['budget'];
$soon = $_POST['soon'];
$pref = $_POST['pref'];

$sql = "INSERT INTO registration (name, email, phone, comp, cname, pno, loc, fund, budget, soon, pref) VALUES ('$name', '$email', '$phone','$comp', '$cname', '$pno', '$loc', '$fund', '$budget', '$soon', '$pref')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	//API Url
	$url = 'http://192.168.43.13:3001/test';
	 
	//Initiate cURL.
	$ch = curl_init($url);
	 
	//The JSON data.
	$jsonData = array(
		'name' => $name,
		'email' => $email,
		'budget' => $budget
	);
	 
	//Encode the array into JSON.
	$jsonDataEncoded = json_encode($jsonData);
	 
	//Tell cURL that we want to send a POST request.
	curl_setopt($ch, CURLOPT_POST, 1);
	 
	//Attach our encoded JSON string to the POST fields.
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	 
	//Set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	 
	//Execute the request
	$result = curl_exec($ch);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>