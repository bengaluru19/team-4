<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
// Escape user inputs for security
$uid=(int) 1;

$type =  $_POST['type'];
$gmap =  $_POST['gmap'];
$numstudent = $_POST['numstudent'];
$age =  $_POST['age'];
$area = (int) 750;

// changes made here . Added int over here.
$budget =  (int)$_POST['budget'];

$snake =  $_POST['snake'];
$genpub =  $_POST['genpub'];
$vandalism =  $_POST['vandalism'];
$soilcondition =  $_POST['soilcondition'];
$elementsonsite =  $_POST['elementsonsite'];
$undergroundwires =  $_POST['undergroundwires'];
$electricpoles =  $_POST['electricpoles'];
$trees =  $_POST['trees'];
$rocks =  $_POST['rocks'];
$waterlogging =  $_POST['waterlogging'];
$highwaytraffic =  $_POST['highwaytraffic'];
$waterbodies =  $_POST['waterbodies'];

$caterdisabled =  $_POST['caterdisabled'];
$maintainreq =  $_POST['maintainreq'];

$particular =  $_POST['particular'];
$routine =  $_POST['routine'];

$sql = "INSERT INTO projdetails (uid, type, gmap, numstudent, age, area, budget) VALUES ('$uid', '$type', '$gmap','$numstudent', '$age', '$area', '$budget')";
if ($conn->query($sql) === TRUE) {
	echo "New record created successfully in projdetails";	
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql1 = "INSERT INTO site (uid, snake, genpub, vandalism, soilcondition, elementsonsite, undergroundwires, electricpoles, trees, rocks, waterlogging, highwaytraffic,waterbodies) VALUES ('$uid', '$snake', '$genpub', '$vandalism', '$soilcondition', '$elementsonsite', '$undergroundwires', '$electricpoles', '$trees', '$rocks', '$waterlogging', '$highwaytraffic', '$waterbodies')";
if ($conn->query($sql1) === TRUE) {
	echo "New record created successfully in site";	
} 
else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
}


//selecting unique sid from database
$sqli = 'SELECT sid FROM site WHERE uid=' .(int) $uid.';' ;
$resulti = $conn->query($sqli);
if ($resulti->num_rows > 0) {
    // output data of each row
    while($row = $resulti->fetch_assoc()) {
        $sid=$row['sid'];
    }
} else {
    echo "0 results";
}

$sql2 = "INSERT INTO disabled (uid, sid, caterdisabled, maintainreq) VALUES ('$uid', '$sid', '$caterdisabled','$maintainreq')";
if ($conn->query($sql2) === TRUE) {
	echo "New record created successfully in disabled";	
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql3 = "INSERT INTO specificinfo (uid, sid, particular, routine) VALUES ('$uid', '$sid', '$particular','$routine')";
if ($conn->query($sql3) === TRUE) {
	echo "New record created successfully in specificinfo";	
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


// CODE ADDED BY RUTVIK 

// ADdding tthiings heree............
// FOR TAKING area, budget, snake from table design, take out the template 
//store the templates as an array
// code newly addded
// FOR TAKING area, budget, snake from table design, take out the template 
//store the templates as an array
// code newly addded

if (strcmp($snake,"yes")==0){
	$snake="Yes";
}else{
	$snake='No';
}
/* echo $budget;
echo $snake;
echo $area; */

$sql_get_templates = 'SELECT template FROM design WHERE area=' .(int) $area . ' AND budget= ' . ( int)$budget . ' AND snake=  \'' . $snake . '\';'  ;
$result = $conn->query($sql_get_templates);

$sql_get_templates2 = 'SELECT email FROM registration WHERE uid=' .(int) $uid.';' ;
$result2 = $conn->query($sql_get_templates2);

echo gettype($result) ;
$someJSON = json_encode($result);
// handle when no queries is returned
 $result_templates = [];
   if($result->num_rows>0){
    // output data of each row
	$i = 0;
    while($row = $result->fetch_assoc()) {
		//$result_templates = $row["template"] ;
		array_push($result_templates, 
		$row['template']
		);
		$i = $i + 1;
    }
	
} 

$someJSON2 = json_encode($result2);
// handle when no queries is returned
 $result_templates2 = [];
   if($result2->num_rows>0){
    // output data of each row
	$i = 0;
    while($row2 = $result2->fetch_assoc()) {
		//$result_templates = $row["template"] ;
		array_push($result_templates2, 
		$row2['email']
		);
		$i = $i + 1;
    }
	
} 

 $someJSON = json_encode($result_templates);
 $someJSON2 = json_encode($result_templates2);
/* echo $result_templates[0]; */

//The url you wish to send the POST request to
	$url = 'localhost:3000/submit_survey';
	$ch = curl_init($url);
	
	//The data you want to send via POST
	
	
	$fields = [
		'result_templates'  => $someJSON,
		'email' => $someJSON2
	];
	

	$payload = json_encode(array("user" => $fields));

	//attach encoded JSON string to the POST fields
	curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

	//set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

	//return response instead of outputting
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	//execute the POST request
	$result = curl_exec($ch);

	//close cURL resource
	curl_close($ch);




$conn->close();
?>