<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table

$sql1 = "CREATE TABLE projdetails(
uid INT(6) UNSIGNED,
type VARCHAR(20) NOT NULL,
gmap VARCHAR(50) NOT NULL,
numstudent INT(3) NOT NULL,
age INT(3) NOT NULL,
area VARCHAR(20) NOT NULL,
budget INT(10) NOT NULL
)";
if ($conn->query($sql1) === TRUE) {
    echo "Table projdetails created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql2 = "CREATE TABLE site (
uid INT(6) UNSIGNED,
sid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
snake VARCHAR(5) NOT NULL,
genpub VARCHAR(5) NOT NULL,
vandalism VARCHAR(5) NOT NULL,
soilcondition VARCHAR(10),
elementsonsite VARCHAR(5) NOT NULL,
undergroundwires VARCHAR(5) NOT NULL,
electricpoles VARCHAR(5) NOT NULL,
trees VARCHAR(5) NOT NULL,
rocks VARCHAR(5) NOT NULL,
waterlogging VARCHAR(5) NOT NULL,
highwaytraffic VARCHAR(5) NOT NULL,
waterbodies VARCHAR(20) NOT NULL,
FOREIGN KEY(uid) REFERENCES registration(uid)
)";
if ($conn->query($sql2) === TRUE) {
    echo "Table site created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql3="CREATE TABLE disabled(
uid INT(6) UNSIGNED,
sid INT(6) UNSIGNED,
caterdisabled  VARCHAR(5) NOT NULL,
maintainreq VARCHAR(5) NOT NULL
)";
if ($conn->query($sql3) === TRUE) {
    echo "Table disabled created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
$sql4="CREATE TABLE specificinfo(
uid INT(6) UNSIGNED,
sid INT(6) UNSIGNED,
particular VARCHAR(30),
routine VARCHAR(20)
);";
if ($conn->query($sql4) === TRUE) {
    echo "Table specific created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>