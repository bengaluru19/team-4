<?php
include 'connection.php'

// Create database
$sql = "CREATE DATABASE anthill";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();
?>