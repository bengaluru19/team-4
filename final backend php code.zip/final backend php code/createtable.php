<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE registration (
uid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
name VARCHAR(30) NOT NULL,
email VARCHAR(50),
phone INT(10) NOT NULL,
comp VARCHAR(10) NOT NULL,
cname VARCHAR(30) NOT NULL,
pno INT(10),
loc VARCHAR(2),
fund VARCHAR(30),
budget INT(10),
soon VARCHAR(30),
pref VARCHAR(30),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>