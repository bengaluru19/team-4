<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
// Escape user inputs for security
$name =  $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$comp = $_POST['comp'];
$cname = $_POST['cname'];
$pno = $_POST['pno'];
$loc = $_POST['loc'];
$fund = $_POST['fund'];
$budget = $_POST['budget'];
$soon = $_POST['soon'];
$pref = $_POST['pref'];

$sql = "INSERT INTO registration (name, email, phone, comp, cname, pno, loc, fund, budget, soon, pref) VALUES ('$name', '$email', '$phone','$comp', '$cname', '$pno', '$loc', '$fund', '$budget', '$soon', '$pref')";

if ($conn->query($sql) === TRUE) {
	echo "New record created successfully";
	//The url you wish to send the POST request to
	$url = 'localhost:3000/test';
	$ch = curl_init($url);
	//The data you want to send via POST
	$fields = [
		'name '      => $name,
		'email' => $email,
		'budget'         => $budget
	];

	$payload = json_encode(array("user" => $fields));

	//attach encoded JSON string to the POST fields
	curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

	//set the content type to application/json
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

	//return response instead of outputting
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	//execute the POST request
	$result = curl_exec($ch);

	//close cURL resource
	curl_close($ch);

	
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>