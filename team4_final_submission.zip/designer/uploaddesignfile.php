<?php

// Database configuration OR  Include the database configuration file
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "anthill";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$parea = $_POST['harea'];
$area = (int)$parea;
$pbudget = $_POST['hbudget'];
$budget = (int)$pbudget;
$snake = $_POST['snake'];
$img = $_POST['img'];	

$sql = "INSERT INTO design (area, budget, snake, template) VALUES ('$area', '$budget', '$snake','$img')";

if ($conn->query($sql) === TRUE) {
	echo "New record created successfully";
} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

echo $area;
echo $budget;
echo $snake;
echo $img;
?>