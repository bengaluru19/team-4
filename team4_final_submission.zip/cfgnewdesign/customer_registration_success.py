from flask import Flask, request, abort
import  smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

app = Flask(__name__)
@app.route('/test',methods=['POST'])
def hello_world():
    print(request.get_json())
    customer_email = request.json['user']['email']
    sender_email = "**********@gmail.com"
    receiver_email = customer_email
    password = '************'
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = customer_email
    msg['Subject'] = "Project Design"
    body = "Thank you for contacting us at Anthill Creations.\n Sorry we don't take orders less than Rs.100000.\nPlease Contact AntHill Creations for Fundraises.\n http://192.168.43.13:8080/cfg/survey.html"
    message = MIMEMultipart("alternative")
    msg.attach(MIMEText(body, 'plain'))
    filename = "helpage-brochure.pdf"
    attachment = open("C:/xampp/htdocs/cfgnewdesign/helpage-brochure.pdf", 'rb')
    p = MIMEBase('application', 'octet-stream')
    p.set_payload((attachment).read())
    encoders.encode_base64(p)
    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
    msg.attach(p)
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login(sender_email, "************")
    text = msg.as_string()
    s.sendmail(sender_email, receiver_email, text)
    s.quit()
    return(customer_email)
 

if __name__== '__main__':
   app.run(host='localhost',port='3000',debug=True)
