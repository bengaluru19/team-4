from flask import Flask,request, abort
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

app = Flask(__name__)


@app.route('/submit_survey', methods=['POST'])
def hello_world():
	if not request.json:
		abort(400)
	r=request.get_json()
	template_id = request.json['user']['result_templates']
	customer_email = request.json['user']['email']
	print(template_id)
	
	customer_email=list(customer_email)
	
	customer_email.pop(0)
	customer_email.pop(0)
	customer_email.pop(-1)
	customer_email.pop(-1)
	customer_email="".join(str(e) for e in customer_email)
	
	template_id=list(template_id)
	template_id.pop(0)
	template_id.pop(0)
	template_id.pop(-1)
	template_id.pop(-1)
	template_id="".join(str(e) for e in template_id)
	sender_email = "*********@gmail.com"
	receiver_email = customer_email
	print(customer_email)
	password = '********'
	msg = MIMEMultipart()
	msg['From'] = sender_email
	msg['To'] = customer_email
	msg['Subject'] = "Project Design"
	body = """Thank you for taking out your time to complete our site survey! \n We hope you like the various playscape designs that we have specially curated for you based on your responses.Don’t hesitate to contact us if you have any queries.\nWe shall discuss further details with you over call shortly.\nWe are eager to work with you!"""
	message = MIMEMultipart("alternative")
	msg.attach(MIMEText(body, 'plain'))
	filename = "{}".format(template_id)
	attachment = open("C:/xampp/htdocs/cfgnewdesign/{}".format(template_id), 'rb')
	p = MIMEBase('application', 'octet-stream')
	p.set_payload((attachment).read())
	encoders.encode_base64(p)
	p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
	msg.attach(p)
	s = smtplib.SMTP('smtp.gmail.com', 587)
	s.starttls()
	s.login(sender_email, "************")
	text = msg.as_string()
	s.sendmail(sender_email, '{}'.format(customer_email), text)
	s.quit()

	return (customer_email)


if __name__ == '__main__':
	app.run(host='localhost', port='3001',debug = True)
