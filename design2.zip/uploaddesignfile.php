<?php

// Database configuration OR  Include the database configuration file
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "root";
$dbName     = "anthill";

$parea = $_POST['harea'];
$area = (int)$parea;
$pbudget = $_POST['hbudget'];
$budget = (int)$pbudget;
$snake = (int)$_POST['snake'];
$image = $_FILES['fileToUpload']['tmp_name'];
$img = file_get_contents($image);

$con = mysqli_connect($dbhost,$dbUsername,$dbPassword,$dbName);
$q = "INSERT INTO DESIGN(area,budget,snake) VALUES ($area,$budget,$values)";
$p = mysqli_query($con, $q);

$sql = "insert into DESIGN (template) values(?)";
$stmt = mysqli_prepare($con,$sql);
mysqli_stmt_bind_param($stmt, "s",$img);
mysqli_stmt_execute($stmt);

?>